/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AssignmentPart1;

import AssignmentPart1.Series;
import java.util.Scanner;

/**
 *
 * @author lukem
 */
public class SeriesModel {

    Series send = new Series();

    private String SeriesId = "";
    private String SeriesName = "";
    private String SeriesAge = "";
    private String SeriesNumberOfEpisodes = "";

    /*public SeriesModel(String SeriesId, String SeriesName, String SeriesAge, String SeriesNumberOfEpisodes) {
        this.SeriesId = SeriesId;
        this.SeriesName = SeriesName;
        this.SeriesAge = SeriesAge;
        this.SeriesNumberOfEpisodes = SeriesNumberOfEpisodes;
    }*/
    public String getSeriesId() {
        return SeriesId;
    }

    public void setSeriesId(String SeriesId) {
        this.SeriesId = SeriesId;
    }

    public String getSeriesName() {
        return SeriesName;
    }

    public void setSeriesName(String SeriesName) {
        this.SeriesName = SeriesName;
    }

    public String getSeriesAge() {
        return SeriesAge;
    }

    public void setSeriesAge(String SeriesAge) {
        this.SeriesAge = SeriesAge;
    }

    public String getSeriesNumberOfEpisodes() {
        return SeriesNumberOfEpisodes;
    }

    public void setSeriesNumberOfEpisodes(String SeriesNumberOfEpisodes) {
        this.SeriesNumberOfEpisodes = SeriesNumberOfEpisodes;
    }

    public void Menu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n=== TV SERIES MANAGER ===");
            System.out.println("1. Capture a new series");
            System.out.println("2. Search for a series");
            System.out.println("3. Update series age restriction");
            System.out.println("4. Delete a series");
            System.out.println("5. Print Series Report");
            System.out.println("6. Exit Application");
            System.out.print("Enter your choice: ");
            System.out.println("    ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1: // capture
                    send.CaptureSeries();
                    break;
                case 2: // search
                    send.SearchSeries(); 
                    break;
                case 3: // update
                    send.UpdateSeries();
                    break;
                case 4: // delete
                    send.DeleteSeries();
                    break;
                case 5: // report
                    send.SeriesReport();
                    break;
                case 6: // exit
                    send.ExitSeriesApplication();
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 6);

        scanner.close(); 
    }
    
    public static void main(String[] args) {
        SeriesModel test = new SeriesModel();
        test.Menu();
    }

}
