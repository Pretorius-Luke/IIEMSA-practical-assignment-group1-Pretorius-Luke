/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AssignmentPart1;

import java.util.Scanner;

/**
 *
 * @author lukem
 */
public class Series {

    String[][] allSeries = new String[100][4];
    int seriesCount = 0;
    Scanner sc = new Scanner(System.in);

    public void CaptureSeries() {
        String id = "";
        String name = "";
        String age = "";
        String numEp = "";
        boolean validInput1 = false;
        boolean validInput2 = false;

        System.out.println("CAPTURE NEW SERIES");
        System.out.println("*".repeat(20));

        System.out.println("Enter series ID:");
        id = sc.nextLine();

        System.out.println("Enter series name:");
        name = sc.nextLine();
        while (!validInput1) {
            System.out.println("Enter series age restriction between 2-18:");
            age = sc.nextLine();

            try {
                int ageNum = Integer.parseInt(age);
                if (ageNum >= 2 && ageNum <= 18) {
                    allSeries[seriesCount][2] = age;
                    validInput1 = true;
                } else {
                    System.out.println("You have entered a incorrect series age!!!");
                }

            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number between 2-18.");
            }

        }

        while (!validInput2) {
            System.out.println("Enter the number of episodes in series:");
            numEp = sc.nextLine();

            try {
                int checkNumEp = Integer.parseInt(numEp);
                if (checkNumEp > 0) {
                    allSeries[seriesCount][3] = numEp;
                    validInput2 = true;
                } else {
                    System.out.println("You have entered a incorrect number of episodes!!!");
                }

            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number that isnt bellow 1!!!");
            }

        }

        //claude.ai was used for this method
        if (seriesCount < allSeries.length) {
            allSeries[seriesCount][0] = id;
            allSeries[seriesCount][1] = name;
            //allSeries[seriesCount][2] = age;
            //allSeries[seriesCount][3] = numEp;
            seriesCount++;
            System.out.println("Series added successfully!");
        } else {
            System.out.println("Series storage is full!");
        }

    }

    public void SearchSeries() {
        System.out.println("Enter Series ID:");
        String search = sc.nextLine();

        for (int i = 0; i < seriesCount; i++) {
            if (allSeries[i][0].equals(search)) {
                System.out.println("Found: "
                        + "\n name: " + allSeries[i][1]
                        + "\n age restriction: " + allSeries[i][2]
                        + "\n number of episodes: " + allSeries[i][3]);
            }
        }

    }

    public void UpdateSeries() {
        String newID = "";
        String newName = "";
        String newAge = "";
        String newNumEp = "";
        System.out.println("Enter ID of series to change:");
        String id = sc.nextLine();

        for (int i = 0; i < seriesCount; i++) {
            if (allSeries[i][0].equals(id)) {
                System.out.println("Enter new series ID:");
                newID = sc.nextLine();

                System.out.println("Enter new series name:");
                newName = sc.nextLine();

                System.out.println("Enter new series age restriction:");
                newAge = sc.nextLine();

                System.out.println("Enter the new number of episodes in series:");
                newNumEp = sc.nextLine();

                allSeries[i][0] = newID;
                allSeries[i][1] = newName;
                allSeries[i][2] = newAge;
                allSeries[i][3] = newNumEp;
                System.out.println("Series update succesful");

            }

        }
        System.out.println("Series not found");

    }

    public void DeleteSeries() {
        System.out.print("Enter Series ID to delete: ");
        String deleteID = sc.nextLine();
        System.out.println("Are you sure you want to delete series " + deleteID + " from the systems? Yes (Y/y) to delete");
        String confirm = sc.nextLine().toUpperCase();
        boolean found = false;

        if (confirm.equals("Y")) {
            for (int i = 0; i < seriesCount; i++) {
                if (allSeries[i][0].equals(deleteID)) {

                    for (int j = i; j < seriesCount - 1; j++) {
                        allSeries[j][0] = allSeries[j + 1][0];
                        allSeries[j][1] = allSeries[j + 1][1];
                        allSeries[j][2] = allSeries[j + 1][2];
                        allSeries[j][3] = allSeries[j + 1][3];
                    }
                    seriesCount--;
                    System.out.println("Series with series id" + deleteID + " was deleted!");
                    System.out.println("-".repeat(40));
                    found = true;
                    break;
                }
            }
        } else {
            System.out.println("");
        }

        if (!found) {
            System.out.println("Series not found!");
        }
    }

    public void SeriesReport() {

        for (int i = 0; i < seriesCount; i++) {
            System.out.println("-------------------");
            System.out.println("Series " + (i + 1) + ":");
            System.out.println("ID: " + allSeries[i][0]);
            System.out.println("Name: " + allSeries[i][1]);
            System.out.println("Age: " + allSeries[i][2]);
            System.out.println("Episodes: " + allSeries[i][3]);
            System.out.println("-------------------");

        }
    }

    public void ExitSeriesApplication() {
        System.out.println("\n=== EXITING APPLICATION ===");
        System.out.println("Thank you for using TV Series Manager!");
        System.out.println("Goodbye!");

    }

}
