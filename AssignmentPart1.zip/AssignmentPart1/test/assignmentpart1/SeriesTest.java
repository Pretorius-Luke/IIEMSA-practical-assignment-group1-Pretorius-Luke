package assignmentpart1;

import assignmentpart1.Series;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Scanner;

public class SeriesTest {
    
    private Series series;
    private final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    
    @BeforeEach
    public void setUp() {
        series = new Series();
        System.setOut(new PrintStream(outputStream));
        
        series.allSeries[0][0] = "S001";
        series.allSeries[0][1] = "Breaking Bad";
        series.allSeries[0][2] = "18";
        series.allSeries[0][3] = "62";
        
        series.allSeries[1][0] = "S002";
        series.allSeries[1][1] = "Friends";
        series.allSeries[1][2] = "12";
        series.allSeries[1][3] = "236";
        
        series.seriesCount = 2;
    }
    
    @AfterEach
    public void tearDown() {
        System.setOut(originalOut);
    }
    
    @Test
    public void TestSearchSeries() {
        String input = "S001\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        series.sc = new Scanner(System.in);
        
        series.SearchSeries();
        
        String output = outputStream.toString();
        assertTrue(output.contains("Found:"));
        assertTrue(output.contains("Breaking Bad"));
        assertTrue(output.contains("age restriction: 18"));
        assertTrue(output.contains("number of episodes: 62"));
    }
    
    @Test
    public void TestSearchSeries_SeriesNotFound() {
        String input = "S999\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        series.sc = new Scanner(System.in);
        
        series.SearchSeries();
        
        String output = outputStream.toString();
        assertFalse(output.contains("Found:"));
        assertFalse(output.contains("Breaking Bad"));
        assertFalse(output.contains("Friends"));
    }
    
    @Test
    public void TestUpdateSeries() {
        String input = "S001\nS001-NEW\nBreaking Bad Updated\n16\n65\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        series.sc = new Scanner(System.in);
        
        series.UpdateSeries();
        
        String output = outputStream.toString();
        assertTrue(output.contains("Series update succesful"));
        
        assertEquals("S001-NEW", series.allSeries[0][0]);
        assertEquals("Breaking Bad Updated", series.allSeries[0][1]);
        assertEquals("16", series.allSeries[0][2]);
        assertEquals("65", series.allSeries[0][3]);
    }
    
    @Test
    public void TestDeleteSeries() {
        String input = "S001\nY\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        series.sc = new Scanner(System.in);
        int originalCount = series.seriesCount;
        
        series.DeleteSeries();
        
        String output = outputStream.toString();
        assertTrue(output.contains("Series with series idS001 was deleted!"));
        
        assertEquals(originalCount - 1, series.seriesCount);
        
        assertEquals("S002", series.allSeries[0][0]);
        assertEquals("Friends", series.allSeries[0][1]);
    }
    
    @Test
    public void TestDeleteSeries_SeriesNotFound() {
        String input = "S999\nY\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        series.sc = new Scanner(System.in);
        int originalCount = series.seriesCount;
        
        series.DeleteSeries();
        
        String output = outputStream.toString();
        assertTrue(output.contains("Series not found!"));
        
        assertEquals(originalCount, series.seriesCount);
    }
    
    @Test
    public void TestSeriesAgeRestriction_AgeValid() {
        String validAge = "12";
        
        try {
            int ageNum = Integer.parseInt(validAge);
            boolean isValid = (ageNum >= 2 && ageNum <= 18);
            assertTrue(isValid, "Age 12 should be valid");
        } catch (NumberFormatException e) {
            fail("Valid age string should parse correctly");
        }
    }
    
    @Test
    public void TestSeriesAgeRestriction_SeriesAgeInValid() {
        String invalidAgeLow = "1";
        try {
            int ageNum = Integer.parseInt(invalidAgeLow);
            boolean isValid = (ageNum >= 2 && ageNum <= 18);
            assertFalse(isValid, "Age 1 should be invalid (below minimum)");
        } catch (NumberFormatException e) {
            fail("Numeric age string should parse correctly");
        }
        
        String invalidAgeHigh = "25";
        try {
            int ageNum = Integer.parseInt(invalidAgeHigh);
            boolean isValid = (ageNum >= 2 && ageNum <= 18);
            assertFalse(isValid, "Age 25 should be invalid (above maximum)");
        } catch (NumberFormatException e) {
            fail("Numeric age string should parse correctly");
        }
        
        String invalidAgeText = "abc";
        assertThrows(NumberFormatException.class, () -> {
            Integer.parseInt(invalidAgeText);
        }, "Non-numeric age should throw NumberFormatException");
    }
}
