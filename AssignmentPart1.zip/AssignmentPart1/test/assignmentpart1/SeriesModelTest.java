/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package assignmentpart1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lukem
 */
public class SeriesModelTest {
    
    public SeriesModelTest() {
    }

    @Test
    public void testGetSeriesId() {
    }

    @Test
    public void testSetSeriesId() {
    }

    @Test
    public void testGetSeriesName() {
    }

    @Test
    public void testSetSeriesName() {
    }

    @Test
    public void testGetSeriesAge() {
    }

    @Test
    public void testSetSeriesAge() {
    }

    @Test
    public void testGetSeriesNumberOfEpisodes() {
    }

    @Test
    public void testSetSeriesNumberOfEpisodes() {
    }

    @Test
    public void testMenu() {
    }

    @Test
    public void testMain() {
    }
    
}
