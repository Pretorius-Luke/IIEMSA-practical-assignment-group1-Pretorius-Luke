/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignmentpart2;

import java.util.Scanner;

/**
 *
 * @author lukem
 */
public class Ui extends Character{
    
    //VillianAttributes vil = new VillianAttributes("");

    public Ui(String heroName) {
        super(heroName);
    }
    
    

    public void Ending() {
        System.out.println("        ______");
        System.out.println("       /     /\\");
        System.out.println("      /     /  \\");
        System.out.println("     /_____/----\\_   (  ");
        System.out.println("                     ).  ");
        System.out.println("   _ ___          o (:') o   ");
        System.out.println("(@))_))          o ~/~~\\~ o   ");
        System.out.println("                  o  o  o");
        System.out.println("*".repeat(34));
        System.out.println("THIS ADVENTURE HAS COME TO A CLOSE");
    }

    public void Menu() {
        Ui use = new Ui("");
        Scanner scanner = new Scanner(System.in);
        
        int choice;

        do {
            System.out.println("\n=== RogueLike ===");
            System.out.println("1. Create hero");
            System.out.println("2. Create Villian");
            System.out.println("3. Display stats");
            System.out.println("4. Fight");
            System.out.println("5. End adventure");
            System.out.print("Enter your choice: ");
            System.out.println("    ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1: //hero
                    heroLook();
                    Stats();


                    break;
                case 2: //villian
                    villianLook();
                    vil.vilStats();

                    break;
                case 3: //stats
                    System.out.println("HERO STATS");
                    System.out.println("*".repeat(30));
                    DisplayStats();
                    
                    System.out.println("");
                    
                    System.out.println("VILLIAN STATS");
                    System.out.println("*".repeat(30));
                    vil.DisplayStats();

                    break;
                case 4: //fight
                    Fight();

                    break;
                case 5: //end
                    use.Ending();

                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 5);

        scanner.close();
    }

    public static void main(String[] args) {
        Ui use = new Ui("");
        
        use.Menu();

    }

}
