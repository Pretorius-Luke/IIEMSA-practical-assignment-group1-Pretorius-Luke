/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package assignmentpart2;

import assignmentpart2.HeroAttributes;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.ByteArrayInputStream;
import java.io.InputStream;

public class HeroAttributesTest {
    
    private HeroAttributes hero;
    private ByteArrayOutputStream outputStreamCaptor;
    private PrintStream originalOut;
    private InputStream originalIn;
    
    @BeforeEach
    void setUp() {
        hero = new HeroAttributes("TestHero");
        outputStreamCaptor = new ByteArrayOutputStream();
        originalOut = System.out;
        originalIn = System.in;
        System.setOut(new PrintStream(outputStreamCaptor));
    }
    
    void tearDown() {
        System.setOut(originalOut);
        System.setIn(originalIn);
    }
    
    @Test
    @DisplayName("Test HeroAttributes constructor")
    void testHeroAttributesConstructor() {
        HeroAttributes testHero = new HeroAttributes("SuperHero");
        assertEquals("SuperHero", testHero.getHeroName());
        assertNotNull(testHero.allStats);
    }
    
    @Test
    @DisplayName("Test setHeroName and getHeroName")
    void testHeroNameMethods() {
        hero.setHeroName("NewHero");
        assertEquals("NewHero", hero.getHeroName());
        
        hero.setHeroName("");
        assertEquals("", hero.getHeroName());
        
        hero.setHeroName("Another Hero");
        assertEquals("Another Hero", hero.getHeroName());
    }
    
    @Test
    @DisplayName("Test Stats with valid input")
    void testStatsValidInput() {
        String input = "7\n5\n9\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        hero = new HeroAttributes("TestHero");
        
        hero.Stats();
        
        assertEquals("7", hero.getAttack());
        assertEquals("5", hero.getDefense());
        assertEquals("9", hero.getHealth());
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("Enter stats for you character"));
        assertTrue(output.contains("Enter your heros Attack stat"));
        assertTrue(output.contains("Enter your heros Defense stat"));
        assertTrue(output.contains("Enter your heros Health stat"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test Stats with invalid then valid input")
    void testStatsInvalidThenValid() {
        String input = "0\n11\n-1\nabc\n6\n3\n8\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        hero = new HeroAttributes("TestHero");
        
        hero.Stats();
        
        assertEquals("6", hero.getAttack());
        assertEquals("3", hero.getDefense());
        assertEquals("8", hero.getHealth());
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("You have entered a incorrect number!"));
        assertTrue(output.contains("Invalid input!"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test Stats boundary values")
    void testStatsBoundaryValues() {
        String input = "1\n10\n1\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        hero = new HeroAttributes("TestHero");
        
        hero.Stats();
        
        assertEquals("1", hero.getAttack());
        assertEquals("10", hero.getDefense());
        assertEquals("1", hero.getHealth());
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test DisplayStats with populated stats")
    void testDisplayStatsPopulated() {
        hero.allStats = new String[4][4];
        hero.allStats[0][0] = "8";
        hero.allStats[0][1] = "6";
        hero.allStats[0][2] = "10";
        
        hero.DisplayStats();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("ATTACK: 8"));
        assertTrue(output.contains("DEFENSE: 6"));
        assertTrue(output.contains("HEALTH: 10"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test DisplayStats with null stats")
    void testDisplayStatsNull() {
        hero.DisplayStats();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("ATTACK: null"));
        assertTrue(output.contains("DEFENSE: null"));
        assertTrue(output.contains("HEALTH: null"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test getter methods")
    void testGetterMethods() {
        assertNull(hero.getAttack());
        assertNull(hero.getDefense());
        assertNull(hero.getHealth());
        
        hero.allStats = new String[4][4];
        hero.allStats[0][0] = "9";
        hero.allStats[0][1] = "4";
        hero.allStats[0][2] = "7";
        
        assertEquals("9", hero.getAttack());
        assertEquals("4", hero.getDefense());
        assertEquals("7", hero.getHealth());
    }
    
    @Test
    @DisplayName("Test allStats array initialization")
    void testAllStatsInitialization() {
        assertNotNull(hero.allStats);
        assertEquals(4, hero.allStats.length);
        assertEquals(4, hero.allStats[0].length);
        
        assertNull(hero.allStats[0][0]);
        assertNull(hero.allStats[0][1]);
        assertNull(hero.allStats[0][2]);
    }
    
    @Test
    @DisplayName("Test count variable functionality")
    void testCountVariable() {
        String input = "5\n5\n5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        hero = new HeroAttributes("TestHero");
        
        assertEquals(0, hero.count);
        
        hero.Stats();
        
        assertEquals(1, hero.count);
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test stats persistence after setting")
    void testStatsPersistence() {
        hero.allStats = new String[4][4];
        hero.allStats[0][0] = "10";
        hero.allStats[0][1] = "2";
        hero.allStats[0][2] = "6";
        
        assertEquals("10", hero.getAttack());
        assertEquals("10", hero.getAttack());
        
        assertEquals("2", hero.getDefense());
        assertEquals("6", hero.getHealth());
    }
    
    @Test
    @DisplayName("Test maximum valid input")
    void testMaximumValidInput() {
        String input = "10\n10\n10\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        hero = new HeroAttributes("MaxHero");
        
        hero.Stats();
        
        assertEquals("10", hero.getAttack());
        assertEquals("10", hero.getDefense());
        assertEquals("10", hero.getHealth());
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test minimum valid input")
    void testMinimumValidInput() {
        String input = "1\n1\n1\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        hero = new HeroAttributes("MinHero");
        
        hero.Stats();
        
        assertEquals("1", hero.getAttack());
        assertEquals("1", hero.getDefense());
        assertEquals("1", hero.getHealth());
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test multiple invalid inputs before valid")
    void testMultipleInvalidInputs() {
        String input = "0\n11\nabc\n-5\n15\nxy\n8\n0\n11\n3\n-1\n12\n9\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        hero = new HeroAttributes("TestHero");
        
        hero.Stats();
        
        assertEquals("8", hero.getAttack());
        assertEquals("3", hero.getDefense());
        assertEquals("9", hero.getHealth());
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("You have entered a incorrect number!"));
        assertTrue(output.contains("Invalid input!"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test duplicate stats setting")
    void testDuplicateStatsIncrement() {
        String input1 = "5\n3\n7\n";
        String input2 = "8\n6\n4\n";
        
        System.setIn(new ByteArrayInputStream(input1.getBytes()));
        hero = new HeroAttributes("TestHero");
        hero.Stats();
        assertEquals(1, hero.count);
        
        System.setIn(new ByteArrayInputStream(input2.getBytes()));
        hero.Stats();
        assertEquals(2, hero.count);
        
        tearDown();
    }
}