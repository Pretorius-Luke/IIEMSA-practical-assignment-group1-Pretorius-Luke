/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package assignmentpart2;



import assignmentpart2.HeroAttributes;
import assignmentpart2.Character;
import assignmentpart2.Ui;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.ByteArrayInputStream;
import java.io.InputStream;

public class UiTest {
    
    private Ui ui;
    private ByteArrayOutputStream outputStreamCaptor;
    private PrintStream originalOut;
    private InputStream originalIn;
    
    @BeforeEach
    void setUp() {
        ui = new Ui("TestUI");
        outputStreamCaptor = new ByteArrayOutputStream();
        originalOut = System.out;
        originalIn = System.in;
        System.setOut(new PrintStream(outputStreamCaptor));
    }
    
    void tearDown() {
        System.setOut(originalOut);
        System.setIn(originalIn);
    }
    
    @Test
    @DisplayName("Test Ui constructor")
    void testUiConstructor() {
        Ui testUi = new Ui("TestHero");
        assertEquals("TestHero", testUi.getHeroName());
        assertTrue(testUi instanceof Character);
        assertTrue(testUi instanceof HeroAttributes);
    }
    
    @Test
    @DisplayName("Test Ending method output")
    void testEndingOutput() {
        ui.Ending();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("______"));
        assertTrue(output.contains("THIS ADVENTURE HAS COME TO A CLOSE"));
        assertTrue(output.contains("*".repeat(34)));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test Menu displays correctly")
    void testMenuDisplay() {
        String input = "5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        ui.Menu();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("=== RogueLike ==="));
        assertTrue(output.contains("1. Create hero"));
        assertTrue(output.contains("2. Create Villian"));
        assertTrue(output.contains("3. Display stats"));
        assertTrue(output.contains("4. Fight"));
        assertTrue(output.contains("5. End adventure"));
        assertTrue(output.contains("Enter your choice:"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test Menu option 1 - Create hero")
    void testMenuOption1() {
        String input = "1\nTestHero\n8\n6\n10\n5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        ui.Menu();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("Enter Hero Name"));
        assertTrue(output.contains("Enter stats for you character"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test Menu option 2 - Create villain")
    void testMenuOption2() {
        String input = "2\nTestVillain\n7\n5\n9\n5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        ui.Menu();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("Enter villian Name"));
        assertTrue(output.contains("Enter stats for your villian"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test Menu option 3 - Display stats")
    void testMenuOption3() {
        ui.allStats = new String[4][4];
        ui.allStats[0][0] = "8";
        ui.allStats[0][1] = "6";
        ui.allStats[0][2] = "10";
        
        ui.vil.allStats = new String[4][4];
        ui.vil.allStats[0][0] = "7";
        ui.vil.allStats[0][1] = "5";
        ui.vil.allStats[0][2] = "9";
        
        String input = "3\n5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        ui.Menu();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("HERO STATS"));
        assertTrue(output.contains("VILLIAN STATS"));
        assertTrue(output.contains("*".repeat(30)));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test Menu option 5 - End adventure")
    void testMenuOption5() {
        String input = "5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        ui.Menu();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("THIS ADVENTURE HAS COME TO A CLOSE"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test Menu invalid option")
    void testMenuInvalidOption() {
        String input = "99\n5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        ui.Menu();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("Invalid choice! Please try again."));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test Menu multiple invalid options")
    void testMenuMultipleInvalidOptions() {
        String input = "0\n-1\nabc\n99\n5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        ui.Menu();
        
        String output = outputStreamCaptor.toString();
        int invalidCount = output.split("Invalid choice! Please try again.").length - 1;
        assertTrue(invalidCount >= 1);
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test Menu loops correctly")
    void testMenuLoop() {
        String input = "1\nHero1\n5\n5\n5\n2\nVillain1\n4\n4\n4\n5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        ui.Menu();
        
        String output = outputStreamCaptor.toString();
        int menuCount = output.split("=== RogueLike ===").length - 1;
        assertTrue(menuCount >= 3);
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test Menu option 4 requires setup")
    void testMenuOption4RequiresSetup() {
        ui.allStats = new String[4][4];
        ui.allStats[0][0] = "8";
        ui.allStats[0][1] = "6";
        ui.allStats[0][2] = "10";
        
        ui.vil.allStats = new String[4][4];
        ui.vil.allStats[0][0] = "7";
        ui.vil.allStats[0][1] = "5";
        ui.vil.allStats[0][2] = "9";
        
        ui.setHeroName("TestHero");
        ui.vil.setVillianName("TestVillain");
        
        String input = "4\n5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        ui.Menu();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("VS"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test inheritance from Character")
    void testInheritanceFromCharacter() {
        assertTrue(ui instanceof Character);
        assertTrue(ui instanceof HeroAttributes);
        
        ui.setHeroName("InheritanceTest");
        assertEquals("InheritanceTest", ui.getHeroName());
        
        assertNotNull(ui.vil);
    }
    
    @Test
    @DisplayName("Test complete workflow")
    void testCompleteWorkflow() {
        String input = "1\nWorkflowHero\n8\n6\n10\n2\nWorkflowVillain\n7\n5\n9\n3\n5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        ui.Menu();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("WorkflowHero"));
        assertTrue(output.contains("WorkflowVillain"));
        assertTrue(output.contains("HERO STATS"));
        assertTrue(output.contains("VILLIAN STATS"));
        assertTrue(output.contains("THIS ADVENTURE HAS COME TO A CLOSE"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test Menu handles sequential operations")
    void testSequentialOperations() {
        String input = "1\nSeqHero\n9\n7\n8\n2\nSeqVillain\n6\n4\n7\n3\n4\n5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        ui.Menu();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("SeqHero"));
        assertTrue(output.contains("SeqVillain"));
        assertTrue(output.contains("ATTACK: 9"));
        assertTrue(output.contains("=== BATTLE END ==="));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test Ending ASCII art format")
    void testEndingAsciiArt() {
        ui.Ending();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("/     /\\"));
        assertTrue(output.contains("/     /  \\"));
        assertTrue(output.contains("/_____/----\\_"));
        assertTrue(output.contains("*_*_"));
        assertTrue(output.contains("(@))_))"));
        
        tearDown();
    }
}
