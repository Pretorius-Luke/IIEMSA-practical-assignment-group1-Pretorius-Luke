/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package assignmentpart2;

import assignmentpart2.HeroAttributes;
import assignmentpart2.Character;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.ByteArrayInputStream;
import java.io.InputStream;

/**
 * Unit tests for Character class
 */
public class CharacterTest {
    
    private Character character;
    private ByteArrayOutputStream outputStreamCaptor;
    private PrintStream originalOut;
    private InputStream originalIn;
    
    @BeforeEach
    void setUp() {
        character = new Character("TestHero");
        outputStreamCaptor = new ByteArrayOutputStream();
        originalOut = System.out;
        originalIn = System.in;
        System.setOut(new PrintStream(outputStreamCaptor));
    }
    
    void tearDown() {
        System.setOut(originalOut);
        System.setIn(originalIn);
    }
    
    @Test
    @DisplayName("Test Character constructor")
    void testCharacterConstructor() {
        Character testCharacter = new Character("Hero1");
        assertEquals("Hero1", testCharacter.getHeroName());
        assertNotNull(testCharacter.vil);
    }
    
    @Test
    @DisplayName("Test calculateDamage with normal values")
    void testCalculateDamageNormal() {
        // Attack: 8, Defense: 4
        // Half defense rounded up: ceil(4/2) = 2
        // Damage: 8 - 2 = 6
        int damage = character.calculateDamage(8, 4);
        assertEquals(6, damage);
    }
    
    @Test
    @DisplayName("Test calculateDamage with odd defense")
    void testCalculateDamageOddDefense() {
        // Attack: 10, Defense: 5
        // Half defense rounded up: ceil(5/2) = ceil(2.5) = 3
        // Damage: 10 - 3 = 7
        int damage = character.calculateDamage(10, 5);
        assertEquals(7, damage);
    }
    
    @Test
    @DisplayName("Test calculateDamage minimum damage")
    void testCalculateDamageMinimum() {
        // Attack: 2, Defense: 8
        // Half defense rounded up: ceil(8/2) = 4
        // Damage would be: 2 - 4 = -2, but minimum is 1
        int damage = character.calculateDamage(2, 8);
        assertEquals(1, damage);
    }
    
    @Test
    @DisplayName("Test calculateDamage with zero defense")
    void testCalculateDamageZeroDefense() {
        // Attack: 5, Defense: 0
        // Half defense rounded up: ceil(0/2) = 0
        // Damage: 5 - 0 = 5
        int damage = character.calculateDamage(5, 0);
        assertEquals(5, damage);
    }
    
    @Test
    @DisplayName("Test calculateDamage with defense of 1")
    void testCalculateDamageDefenseOne() {
        // Attack: 6, Defense: 1
        // Half defense rounded up: ceil(1/2) = ceil(0.5) = 1
        // Damage: 6 - 1 = 5
        int damage = character.calculateDamage(6, 1);
        assertEquals(5, damage);
    }
    
    @Test
    @DisplayName("Test heroLook sets name correctly")
    void testHeroLook() {
        String input = "SuperHero\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        character = new Character(""); // Reset with empty name
        
        character.heroLook();
        
        assertEquals("SuperHero", character.getHeroName());
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("Enter Hero Name"));
        assertTrue(output.contains("Hero Name: SuperHero"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test villianLook sets villain name correctly")
    void testVillianLook() {
        String input = "EvilVillain\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        character.villianLook();
        
        assertEquals("EvilVillain", character.vil.getVillianName());
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("Enter villian Name"));
        assertTrue(output.contains("villian Name: EvilVillain"));
        
        tearDown();
    }
    
    // Helper method to set up character stats for fighting tests
    private void setupCharacterStats(Character character) {
        // Manually set hero stats
        character.allStats = new String[4][4];
        character.allStats[0][0] = "8"; // Attack
        character.allStats[0][1] = "5"; // Defense
        character.allStats[0][2] = "10"; // Health
        
        // Manually set villain stats
        character.vil.allStats = new String[4][4];
        character.vil.allStats[0][0] = "6"; // Attack
        character.vil.allStats[0][1] = "3"; // Defense
        character.vil.allStats[0][2] = "8"; // Health
        
        character.setHeroName("TestHero");
        character.vil.setVillianName("TestVillain");
    }
    
    @Test
    @DisplayName("Test Fight method output format")
    void testFightOutput() {
        setupCharacterStats(character);
        
        character.Fight();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("TestHero VS TestVillain"));
        assertTrue(output.contains("attacks for"));
        assertTrue(output.contains("damage"));
        assertTrue(output.contains("=== BATTLE END ==="));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test Fight method battle logic")
    void testFightBattleLogic() {
        // Set up a scenario where hero wins quickly
        character.allStats = new String[4][4];
        character.allStats[0][0] = "10"; // High attack
        character.allStats[0][1] = "8";  // High defense
        character.allStats[0][2] = "10"; // High health
        
        character.vil.allStats = new String[4][4];
        character.vil.allStats[0][0] = "2";  // Low attack
        character.vil.allStats[0][1] = "1";  // Low defense
        character.vil.allStats[0][2] = "3";  // Low health
        
        character.setHeroName("StrongHero");
        character.vil.setVillianName("WeakVillain");
        
        character.Fight();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("StrongHero wins the battle!"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test calculateDamage edge cases")
    void testCalculateDamageEdgeCases() {
        // Test with maximum values
        assertEquals(5, character.calculateDamage(10, 10)); // 10 - ceil(10/2) = 10 - 5 = 5
        
        // Test with minimum attack, high defense
        assertEquals(1, character.calculateDamage(1, 10)); // 1 - ceil(10/2) = 1 - 5 = -4, but min is 1
        
        // Test exact half scenarios
        assertEquals(4, character.calculateDamage(6, 4)); // 6 - ceil(4/2) = 6 - 2 = 4
        assertEquals(7, character.calculateDamage(10, 6)); // 10 - ceil(6/2) = 10 - 3 = 7
    }
    
    @Test
    @DisplayName("Test villain object initialization")
    void testVillainInitialization() {
        assertNotNull(character.vil);
        assertEquals("", character.vil.getVillianName());
    }
    
    @Test
    @DisplayName("Test character inherits from HeroAttributes")
    void testInheritance() {
        assertTrue(character instanceof HeroAttributes);
        character.setHeroName("InheritanceTest");
        assertEquals("InheritanceTest", character.getHeroName());
    }
}