/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package assignmentpart2;

import assignmentpart2.VillianAttributes;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.ByteArrayInputStream;
import java.io.InputStream;

/**
 * Unit tests for VillianAttributes class
 */
public class VillianAttributesTest {
    
    private VillianAttributes villain;
    private ByteArrayOutputStream outputStreamCaptor;
    private PrintStream originalOut;
    private InputStream originalIn;
    
    @BeforeEach
    void setUp() {
        villain = new VillianAttributes("TestVillain");
        outputStreamCaptor = new ByteArrayOutputStream();
        originalOut = System.out;
        originalIn = System.in;
        System.setOut(new PrintStream(outputStreamCaptor));
    }
    
    void tearDown() {
        System.setOut(originalOut);
        System.setIn(originalIn);
    }
    
    @Test
    @DisplayName("Test VillianAttributes constructor")
    void testVillianAttributesConstructor() {
        VillianAttributes testVillain = new VillianAttributes("EvilOne");
        assertEquals("EvilOne", testVillain.getVillianName());
        assertNotNull(testVillain.allStats);
    }
    
    @Test
    @DisplayName("Test setVillianName and getVillianName")
    void testVillianNameMethods() {
        villain.setVillianName("NewVillain");
        assertEquals("NewVillain", villain.getVillianName());
        
        villain.setVillianName("");
        assertEquals("", villain.getVillianName());
        
        villain.setVillianName("Another Villain");
        assertEquals("Another Villain", villain.getVillianName());
    }
    
    @Test
    @DisplayName("Test vilStats with valid input")
    void testVilStatsValidInput() {
        String input = "8\n6\n10\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        villain = new VillianAttributes("TestVillain"); // Reset to use new input
        
        villain.vilStats();
        
        assertEquals("8", villain.getAttack());
        assertEquals("6", villain.getDefense());
        assertEquals("10", villain.getHealth());
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("Enter stats for your villian"));
        assertTrue(output.contains("Enter your villians Attack stat"));
        assertTrue(output.contains("Enter your villians Defense stat"));
        assertTrue(output.contains("Enter your villians Health stat"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test vilStats with invalid then valid input")
    void testVilStatsInvalidThenValid() {
        String input = "0\n11\n-1\nabc\n5\n2\n7\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        villain = new VillianAttributes("TestVillain");
        
        villain.vilStats();
        
        assertEquals("5", villain.getAttack());
        assertEquals("2", villain.getDefense());
        assertEquals("7", villain.getHealth());
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("You have entered a incorrect number!"));
        assertTrue(output.contains("Invalid input!"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test vilStats boundary values")
    void testVilStatsBoundaryValues() {
        String input = "1\n10\n1\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        villain = new VillianAttributes("TestVillain");
        
        villain.vilStats();
        
        assertEquals("1", villain.getAttack());
        assertEquals("10", villain.getDefense());
        assertEquals("1", villain.getHealth());
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test DisplayStats with populated stats")
    void testDisplayStatsPopulated() {
        // Manually set stats to test display
        villain.allStats = new String[4][4];
        villain.allStats[0][0] = "7";
        villain.allStats[0][1] = "4";
        villain.allStats[0][2] = "9";
        
        villain.DisplayStats();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("ATTACK: 7"));
        assertTrue(output.contains("DEFENSE: 4"));
        assertTrue(output.contains("HEALTH: 9"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test DisplayStats with null stats")
    void testDisplayStatsNull() {
        villain.DisplayStats();
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("ATTACK: null"));
        assertTrue(output.contains("DEFENSE: null"));
        assertTrue(output.contains("HEALTH: null"));
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test getter methods")
    void testGetterMethods() {
        // Test with null stats (default state)
        assertNull(villain.getAttack());
        assertNull(villain.getDefense());
        assertNull(villain.getHealth());
        
        // Test with populated stats
        villain.allStats = new String[4][4];
        villain.allStats[0][0] = "5";
        villain.allStats[0][1] = "3";
        villain.allStats[0][2] = "8";
        
        assertEquals("5", villain.getAttack());
        assertEquals("3", villain.getDefense());
        assertEquals("8", villain.getHealth());
    }
    
    @Test
    @DisplayName("Test allStats array initialization")
    void testAllStatsInitialization() {
        assertNotNull(villain.allStats);
        assertEquals(4, villain.allStats.length);
        assertEquals(4, villain.allStats[0].length);
        
        // Check that initial values are null
        assertNull(villain.allStats[0][0]);
        assertNull(villain.allStats[0][1]);
        assertNull(villain.allStats[0][2]);
    }
    
    @Test
    @DisplayName("Test count variable functionality")
    void testCountVariable() {
        String input = "5\n5\n5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        villain = new VillianAttributes("TestVillain");
        
        // Initially count should be 0
        assertEquals(0, villain.count);
        
        villain.vilStats();
        
        // After vilStats, count should be incremented
        assertEquals(1, villain.count);
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test stats persistence after setting")
    void testStatsPersistence() {
        villain.allStats = new String[4][4];
        villain.allStats[0][0] = "10";
        villain.allStats[0][1] = "1";
        villain.allStats[0][2] = "5";
        
        // Verify stats persist through multiple calls
        assertEquals("10", villain.getAttack());
        assertEquals("10", villain.getAttack()); // Second call should return same value
        
        assertEquals("1", villain.getDefense());
        assertEquals("5", villain.getHealth());
    }
    
    @Test
    @DisplayName("Test edge case: maximum valid input")
    void testMaximumValidInput() {
        String input = "10\n10\n10\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        villain = new VillianAttributes("MaxVillain");
        
        villain.vilStats();
        
        assertEquals("10", villain.getAttack());
        assertEquals("10", villain.getDefense());
        assertEquals("10", villain.getHealth());
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test edge case: minimum valid input")
    void testMinimumValidInput() {
        String input = "1\n1\n1\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        villain = new VillianAttributes("MinVillain");
        
        villain.vilStats();
        
        assertEquals("1", villain.getAttack());
        assertEquals("1", villain.getDefense());
        assertEquals("1", villain.getHealth());
        
        tearDown();
    }
    
    @Test
    @DisplayName("Test multiple invalid inputs before valid")
    void testMultipleInvalidInputs() {
        String input = "0\n11\nabc\n-5\n15\nxy\n7\n0\n11\n4\n-1\n12\n9\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        villain = new VillianAttributes("TestVillain");
        
        villain.vilStats();
        
        assertEquals("7", villain.getAttack());
        assertEquals("4", villain.getDefense());
        assertEquals("9", villain.getHealth());
        
        String output = outputStreamCaptor.toString();
        assertTrue(output.contains("You have entered a incorrect number!"));
        assertTrue(output.contains("Invalid input!"));
        
        tearDown();
    }
}