/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AssignmentPart2;

import java.util.Scanner;

/**
 *
 * @author lukem
 */
public class HeroAttributes {

    private String heroName;
    private String attack;
    private String defense;
    private String hp;

    String[][] allStats = new String[4][4];
    private Scanner sc = new Scanner(System.in);
    int count = 0;

    public HeroAttributes(String heroName) {
        this.heroName = heroName;

    }

    public String getHeroName() {

        return heroName;
    }

    public void setHeroName(String heroName) {
        this.heroName = heroName;
    }

    public void Stats() {
        System.out.println("Enter stats for you character");

        String atk = "";
        String def = "";
        String hP = "";

        boolean validInput1 = false;
        boolean validInput2 = false;
        boolean validInput3 = false;

        //attack stat
        while (!validInput1) {
            System.out.println("Enter your heros Attack stat (cant be less than 1 or greater than 10):");
            atk = sc.nextLine();

            try {
                int checkAtk = Integer.parseInt(atk);
                if (checkAtk > 0 && checkAtk <= 10) {
                    allStats[0][0] = atk;
                    validInput1 = true;
                } else {
                    System.out.println("You have entered a incorrect number!");
                }

            } catch (NumberFormatException e) {
                System.out.println("Invalid input!");
            }

        }

        //defense stat
        while (!validInput2) {
            System.out.println("Enter your heros Defense stat (cant be less than 1 or greater than 10):");
            def = sc.nextLine();

            try {
                int checkDef = Integer.parseInt(def);
                if (checkDef > 0 && checkDef <= 10) {
                    allStats[0][1] = def;
                    validInput2 = true;
                } else {
                    System.out.println("You have entered a incorrect number!");
                }

            } catch (NumberFormatException e) {
                System.out.println("Invalid input!");
            }

        }

        //health stat
        while (!validInput3) {
            System.out.println("Enter your heros Health stat (cant be less than 1 or greater than 10):");
            hP = sc.nextLine();

            try {
                int checkHP = Integer.parseInt(hP);
                if (checkHP > 0 && checkHP <= 10) {
                    allStats[0][2] = hP;
                    validInput3 = true;
                } else {
                    System.out.println("You have entered a incorrect number!");
                }

            } catch (NumberFormatException e) {
                System.out.println("Invalid input!");
            }

        }

        if (count < allStats.length) {
            allStats[count][0] = atk;
            allStats[count][1] = def;
            allStats[count][2] = hP;
            count++;
        }

    }

    public void DisplayStats() {

        System.out.println("ATTACK: " + allStats[0][0]);
        System.out.println("DEFENSE: " + allStats[0][1]);
        System.out.println("HEALTH: " + allStats[0][2]);

    }

    public String getAttack() {
        return allStats[0][0];
    }

    public String getDefense() {
        return allStats[0][1];
    }

    public String getHealth() {
        return allStats[0][2];
    }

}
