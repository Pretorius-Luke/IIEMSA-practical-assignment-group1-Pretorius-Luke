/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AssignmentPart2;

import java.util.Scanner;

/**
 *
 * @author lukem
 */
public class Character extends HeroAttributes {

    Scanner sc = new Scanner(System.in);

    VillianAttributes vil = new VillianAttributes("");

    public Character(String heroName) {
        super(heroName);
    }

    public void heroLook() {
        System.out.println("Enter Hero Name");
        String name = sc.nextLine();
        setHeroName(name);

        System.out.println("");
        System.out.println(" o");
        System.out.println("/|\\/");
        System.out.println("/ \\");
        System.out.println("Hero Name: " + getHeroName());

    }

    public void villianLook() {
        System.out.println("Enter villian Name");
        String name = sc.nextLine();
        vil.setVillianName(name);

        System.out.println("");
        System.out.println("\\o/");
        System.out.println("/|\\/");
        System.out.println("/ \\");
        System.out.println("villian Name: " + vil.getVillianName());

    }

    public void Fight() {
        System.out.println(getHeroName() + " VS " + vil.getVillianName());
        System.out.println("");
        System.out.println(" o         \\o/");
        System.out.println("/|\\/      \\/|\\");
        System.out.println("/ \\        / \\");

        int heroAttack = Integer.parseInt(getAttack());
        int heroDefense = Integer.parseInt(getDefense());
        int heroHP = Integer.parseInt(getHealth());
        
        int villainAttack = Integer.parseInt(vil.getAttack());
        int villainDefense = Integer.parseInt(vil.getDefense());
        int villainHP = Integer.parseInt(vil.getHealth());

        int heroDamage = calculateDamage(heroAttack, villainDefense);
        int villainDamage = calculateDamage(villainAttack, heroDefense);
        
        
        System.out.println(getHeroName() + " attacks for " + heroDamage + " damage");
        System.out.println("(Attack: " + heroAttack + " - Half Defense: " + (int) Math.ceil(villainDefense / 2.0) + ")");
        
        System.out.println("*".repeat(30));
        
        System.out.println(vil.getVillianName() + " attacks for " + villainDamage + " damage");
        System.out.println("(Attack: " + villainAttack + " - Half Defense: " + (int) Math.ceil(heroDefense / 2.0) + ")");
        
        int turn = 1;
    
    while (heroHP > 0 && villainHP > 0) {
        System.out.println("*".repeat(30));
        System.out.println("--- Turn " + turn + " ---");
        
        villainHP -= heroDamage;
        System.out.println(getHeroName() + " attacks " + vil.getVillianName() + " for " + heroDamage + " damage!");
        System.out.println(vil.getVillianName() + " HP: " + Math.max(0, villainHP));
        
        if (villainHP <= 0) {
            System.out.println();
            System.out.println(getHeroName() + " wins the battle!");
            break;
        }
        
        heroHP -= villainDamage;
        System.out.println(vil.getVillianName() + " attacks " + getHeroName() + " for " + villainDamage + " damage!");
        System.out.println(getHeroName() + " HP: " + Math.max(0, heroHP));
        
        if (heroHP <= 0) {
            System.out.println();
            System.out.println(vil.getVillianName() + " wins the battle!");
            break;
        }
        
        System.out.println();
        turn++;
    }
    
    System.out.println("=== BATTLE END ===");

    }

    public int calculateDamage(int attackValue, int defenseValue) {
        int defenseReduction = (int) Math.ceil(defenseValue / 2.0);
        int damage = Math.max(1, attackValue - defenseReduction);
        return damage;
    }

}
